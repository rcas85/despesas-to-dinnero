# Changelog — Despesas to Dinnero

Histórico de evolução do projeto. Cada entrada registra o que mudou, quando, e por quê.

Formato: `[Versão] - YYYY-MM-DD`

---

## [PWA 1.2.1-beta] - 2026-05-09

### Adicionado
- Sistema de log de debug para versões beta (object store `debug_log` no IndexedDB)
- Captura automática de eventos: `gemini_error`, `parse_error`, `file_read_error`, `runtime_error`, `unhandled_rejection`
- Seção "Debug & Log (beta)" em Configurações com contador de eventos, KB acumulado, botão Copiar, Exportar (.json) e Limpar log
- Build flags `IS_BETA` + `APP_VERSION` no topo do arquivo — quando virar versão estável basta trocar `IS_BETA = false`
- Cap automático do log: 100 entradas / 500 KB com FIFO
- DB_VERSION bumpado para 2 (upgrade automático silencioso para usuários existentes)

### Notas de uso real
- Hospedagem: a IA já identificava número de diárias na justificativa mas não preenchia o campo numérico — corrigido em 1.2.1 (auto-preenchimento de diárias, placa e km)
- Táxi/Uber: PDFs funcionam bem; sugestão de justificativa com origem→destino quando o recibo traz
- Passagem aérea: PDF da Latam testado com sucesso

---

## [PWA 1.2.1] - 2026-05-09

### Adicionado
- Auto-preenchimento de campos condicionais quando a IA extrai (`diarias_extraidas`, `placa_veiculo`, `km_rodados`)
- Prompt do Gemini agora pede explicitamente esses três campos no JSON de retorno

### Mudado
- Diárias e km vão direto para o campo numérico (sem botão "Aplicar"), pois são valores unívocos — diferente de categoria/justificativa que ainda permitem revisão humana

---

## [PWA 1.2.0] - 2026-05-09

### Adicionado
- Suporte a PDF como anexo (botão separado "Anexar PDF" ao lado de "Tirar foto / galeria")
- Card visual para preview de PDF (ícone azul, nome do arquivo, tamanho)
- Sugestão de justificativa pela IA via campo `justificativa_sugerida` no prompt
- Banner verde com botão "Aplicar" para a sugestão de justificativa (mesmo padrão da sugestão de categoria)
- Regras específicas de justificativa por categoria no prompt (refeição, hospedagem, combustível, táxi, pedágio, passagem aérea, aluguel)
- Campos `cidade`, `origem`, `destino` no retorno do Gemini (úteis principalmente para táxi/uber/passagem aérea)
- Persistência de `anexo_tipo` e `anexo_nome_original` no objeto da despesa (preparação para Fase 4 do agente)
- Extensão dinâmica do `foto_path` no pacote de exportação (.pdf ou .jpg)

### Mudado
- ExpenseCard mostra ícone de PDF azul em vez de thumbnail quando anexo é PDF

---

## [PWA 1.1.0] - 2026-05-09

### Adicionado — Fase 2: IA de extração via Gemini
- Helpers `geminiExtractFromImage()` e `geminiTestKey()` chamando `gemini-2.5-flash` no free tier
- Prompt robusto com 48 categorias do Dinnero e heurísticas inline (hotel→Hospedagens, posto→Combustível, restaurante+horário, Uber→Táxi, etc.)
- Campo da chave Gemini em Configurações com toggle olho/olho fechado para visibilidade
- Botão "Testar conexão" com feedback verde/vermelho
- Banner de status da IA na captura: azul (processando), verde (extraído), amarelo (verificar) ou erro
- Badges "IA" / "Verifique" ao lado de cada campo conforme nível de confiança (≥0.8 = verde, abaixo = amarelo)
- Sugestão de categoria como banner pontilhado verde com botão "Aplicar"
- Modo offline gracioso: sem chave ou sem internet, mostra aviso e permite preenchimento manual
- Botão "Re-extrair com IA" na tela de edição
- Confiança da extração persistida em `dados_nf.confianca_extracao`
- Campos `horario` e `cnpj` no retorno do Gemini, persistidos em `dados_nf`

### Decisões tomadas
- Threshold de confiança visual: 0.8 (acima = badge "IA" verde, abaixo = badge "Verifique" amarelo)
- Chave Gemini fica apenas no IndexedDB do dispositivo, nunca trafega para fora além das chamadas à API do Google
- Modo offline não bloqueia uso — usuário sempre consegue preencher manualmente
- Auto-extração roda imediatamente após a foto, sem confirmação — UX mais rápida

---

## [Spec 1.0] - 2026-05-07

### Adicionado
- Especificação técnica inicial completa (10 seções + anexo de discovery)
- Definição da stack: PWA + Vercel + Gemini 2.5 Flash + IndexedDB + iCloud Drive + Claude for Chrome
- Modelo de dados (viagem, despesa, pacote de exportação)
- Mapeamento PWA → Dinnero campo a campo, modal a modal
- Plano de construção em 5 fases
- Lista das 48 categorias do Dinnero
- Perfis das 10 categorias mais usadas pelo Ricardo
- Regras invioláveis do agente Claude for Chrome (nunca submeter, nunca eliminar, etc.)

### Decisões tomadas
- Nome do projeto: "Despesas to Dinnero"
- Idioma da interface: Português (com termos do Dinnero em espanhol nos campos de saída)
- Suporte a modo offline: sim, captura funciona sem internet; IA processa em background quando houver sinal
- Hospedagem: Vercel free tier
- IA: Gemini 2.5 Flash (free tier, 1500 req/dia)
- Armazenamento: IndexedDB local + exportação manual para iCloud Drive
- Modelo de revisão: usuário sempre revisa antes do envio do Reporte; nada é submetido automaticamente

### Discovery realizado (camadas)
- Conversa exploratória inicial sobre problema e ferramentas
- Mapeamento estrutural via Claude for Chrome (3 modais documentados, 49 categorias listadas)
- Word com prints de prestação real de hospedagem (17 prints)
- Word com prints de prestação de refeição (8 páginas)
- Word com prints de campos condicionais (fee, combustível, km rodado)
- Conversa para definir stack tecnológica e arquitetura

---

## Próximas entradas (template para preencher)

```
## [Spec X.Y / PWA X.Y] - YYYY-MM-DD

### Adicionado
-

### Mudado
-

### Removido
-

### Corrigido
-

### Notas de uso real
-
```

---

## Convenções

- **Spec X.Y** = versão da especificação técnica
- **PWA X.Y** = versão da PWA construída
- **Agent X.Y** = versão do prompt-base do agente Claude for Chrome
- Versões evoluem independentemente. Spec pode ir à 1.3 enquanto PWA está na 1.0.
- Mudanças significativas → bump no primeiro dígito (1.x → 2.0). Ajustes pequenos → segundo dígito (1.0 → 1.1).
